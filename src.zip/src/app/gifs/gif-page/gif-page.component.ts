import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gif-page',
  templateUrl: './gif-page.component.html',
  styles: [
  ]
})
export class GifPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
